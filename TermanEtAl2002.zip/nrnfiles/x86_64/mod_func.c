#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;

extern void _I_AHP_reg(void);
extern void _I_Ca_reg(void);
extern void _I_K_reg(void);
extern void _I_L_reg(void);
extern void _I_Na_reg(void);
extern void _I_T_gpe_reg(void);
extern void _I_T_stn_reg(void);
extern void _I_syn_reg(void);

void modl_reg(){
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");

    fprintf(stderr," \"I_AHP.mod\"");
    fprintf(stderr," \"I_Ca.mod\"");
    fprintf(stderr," \"I_K.mod\"");
    fprintf(stderr," \"I_L.mod\"");
    fprintf(stderr," \"I_Na.mod\"");
    fprintf(stderr," \"I_T_gpe.mod\"");
    fprintf(stderr," \"I_T_stn.mod\"");
    fprintf(stderr," \"I_syn.mod\"");
    fprintf(stderr, "\n");
  }
  _I_AHP_reg();
  _I_Ca_reg();
  _I_K_reg();
  _I_L_reg();
  _I_Na_reg();
  _I_T_gpe_reg();
  _I_T_stn_reg();
  _I_syn_reg();
}
