from neuron import h, gui

class Cell(object):
	"""Generic cell template."""
	#
	def __init__(self):
		self.x = 0; self.y = 0; self.z = 0
		self.soma = None
		self.Syn_list = []
		self.Iscale = 0.1
		self.create_sections()
		self.build_subsets()
		self.define_geometry()
		self.define_biophysics()
	#   
	def create_sections(self):
		"""Create the sections of the cell. Remember to do this
		in the form::
		
		h.Section(name='soma', cell=self)
		   
		"""
		raise NotImplementedError("create_sections() is not implemented.")
	#
	def define_geometry(self):
		"""Set the 3D geometry of the cell."""
		raise NotImplementedError("define_geometry() is not implemented.")
	#
	def define_biophysics(self):
		"""Assign the membrane properties across the cell."""
		raise NotImplementedError("define_biophysics() is not implemented.")
	#
	def connect2self(self, thresh=10):
		"""Make a new NetCon with this cell's membrane
		potential at the soma as the source (i.e. the spike detector)
		onto the target passed in (i.e. a synapse on a cell).
		Subclasses may override with other spike detectors."""
		nc = h.NetCon(self.soma(0.5)._ref_v, self.soma)
		nc.threshold = thresh
		return nc
	#
	def get_spikes(self):
		"""Get the spikes as a list of lists."""
		return spiketrain.netconvecs_to_listoflists(self.t_vec, self.id_vec)
	#

	def create_synapse(self,pre,type,g0):
		"""Subclasses should create synapses (such as ExpSyn) at various
		segments and add them to self.Syn_list."""
		#
		syn = h.syn(0.5, sec=self.soma)
		h.setpointer(pre.soma(0.5)._ref_v, 'vg', syn)
		#
		if type=='G2S':
			syn.g0 = g0*self.Iscale
			syn.theta_Hg = -39.0
			syn.theta_g = 30.0
			syn.sigma_Hg = 8.0
			syn.alpha = 5.0
			syn.beta = 1.0
			syn.v0 = -85.0
		#
		if type=='G2G' or type=='S2G':
			syn.theta_Hg = -57.0
			syn.theta_g = 20.0
			syn.sigma_Hg = 2.0
			syn.alpha = 2.0
			syn.beta = 0.08
		#
		if type=='S2G':
			syn.g0 = g0*self.Iscale
			syn.v0 = 0.0
		#
		if type=='G2G':
			syn.g0 = g0*self.Iscale
			syn.v0 = -100.0
		#
		self.Syn_list.append(syn)
	#
	def build_subsets(self):
		"""Build subset lists. This defines 'all', but subclasses may
		want to define others. If overridden, call super() to include 'all'."""
		self.all = h.SectionList()
		self.all.wholetree(sec=self.soma)
	#
	def attach_current_clamp(self):
		"""Attach a current Clamp to a cell.
		#
		:param cell: Cell object to attach the current clamp.
		:param delay: Onset of the injected current.
		:param dur: Duration of the stimulus.
		:param amp: Magnitude of the current.
		:param loc: Location on the dendrite where the stimulus is placed.
		"""
		stim = h.IClamp(self.soma(self.loc))
		stim.delay = self.delay
		stim.dur = self.dur
		stim.amp = self.amp
		#
		return stim
	#
	def set_position(self, x, y, z):
		"""
		Set the base location in 3D and move all other
		parts of the cell relative to that location.
		"""
		for sec in self.all:
			for i in range(int(h.n3d())):
				h.pt3dchange(i, \
					x-self.x+h.x3d(i), \
					y-self.y+h.y3d(i), \
					z-self.z+h.z3d(i), \
					h.diam3d(i))
		self.x = x; self.y = y; self.z = z
	#
	def shape_3D(self):
		"""
		Set the default shape of the cell in 3D coordinates.
		Set soma(0) to the origin (0,0,0)
		"""
		len1 = self.soma.L
		self.soma.push()
		h.pt3dclear()
		h.pt3dadd(0, 0, 0, self.soma.diam)
		h.pt3dadd(len1, 0, 0, self.soma.diam)
		h.pop_section()


class GPe(Cell):  #### Inherits from Cell
	"""Creates basic STN cell with soma only, inserts
	currents, and sets parameters."""
	#
	def __init__(self, delay=0, dur=1e9, amp=0, loc=0.5, cur=False):
		super(GPe,self).__init__()
		self.ident = 'gpe'
		self.delay = delay
		self.dur = dur
		self.amp = amp
		self.loc = loc
		if cur==True:
			self.stim = self.attach_current_clamp()
		#
	#
	def create_sections(self):
		"""Create the sections of the cell."""
		self.soma = h.Section(name='soma', cell=self)
	#
	def define_geometry(self):
		"""Set the 3D geometry of the cell."""
		self.soma.L = self.soma.diam = 12.6157 # microns
		self.shape_3D()
	#
	def define_biophysics(self):
		"""Assign the membrane properties across the cell."""
		for sec in self.all: # 'all' exists in parent object.
			sec.Ra = 100    # Axial resistance in Ohm * cm
			sec.cm = 100      # Membrane capacitance in micro Farads / cm^2
		#
		# Insert appropiate currents
		self.soma.insert('l')
		self.soma.insert('K')
		self.soma.insert('Na')
		self.soma.insert('Tgpe')
		self.soma.insert('Ca')
		self.soma.insert('AHP')
		#
		# Set intercurrent pointers
		h.setpointer(self.soma(0.5)._ref_I_Ca, 'I_Ca', self.soma(0.5).AHP)
		h.setpointer(self.soma(0.5)._ref_I_Tgpe, 'I_T', self.soma(0.5).AHP)
		self.soma.Ca0_AHP = 0.02
		#
		# Set current parameters
		#
		self.soma.g0_l = 0.1*self.Iscale
		self.soma.g0_K = 30.0*self.Iscale
		self.soma.g0_Na = 120.0*self.Iscale
		self.soma.g0_Tgpe = 0.5*self.Iscale
		self.soma.g0_Ca = 0.15*self.Iscale
		self.soma.g0_AHP = 30.0*self.Iscale
		#
		self.soma.v0_l = -55.0
		self.soma.v0_K = self.soma.v0_AHP = -80.0
		self.soma.v0_Na = 55.0
		self.soma.v0_Ca = self.soma.v0_Tgpe = 120.0
		#
		self.soma.tau_1h_Na = 0.27
		self.soma.tau_1n_K = 0.27
		self.soma.tau_0h_Na = 0.05
		self.soma.tau_0n_K = 0.05
		self.soma.tau_r_Tgpe = 30.0
		#
		self.soma.phi_h_Na = 0.05
		self.soma.phi_n_K = 0.05
		self.soma.phi_r_Tgpe = 1.0
		#
		self.soma.k1_AHP = 30.0
		self.soma.kca_AHP = 20.0
		self.soma.epsilon_AHP = 1e-4
		#
		self.soma.theta_m_Na = -37.0
		self.soma.theta_h_Na = -58.0
		self.soma.theta_n_K = -50.0
		self.soma.theta_r_Tgpe = -70.0
		self.soma.theta_a_Tgpe = -57.0
		self.soma.theta_s_Ca = -35.0
		#
		self.soma.theta_th_Na = -40.0
		self.soma.theta_tn_K = -40.0
		#
		self.soma.sigma_m_Na = 10.0
		self.soma.sigma_h_Na = -12.0
		self.soma.sigma_n_K = 14.0
		self.soma.sigma_r_Tgpe = -2.0 
		self.soma.sigma_a_Tgpe = 2.0
		self.soma.sigma_s_Ca = 2.0
		#
		self.soma.sigma_th_Na = -12.0
		self.soma.sigma_tn_K = -12.0
		#
	#